g++ main.cpp exp.h  exp.cpp LiStack.cpp LiStack.h -o exp.out -Wall
echo "ok"
./exp.out
