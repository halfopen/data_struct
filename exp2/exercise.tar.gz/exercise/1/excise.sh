#	time:2014-10-06 
#	author:halfopen
#	version:1

g++ excise1.cpp LinkList.cpp LinkList.h fileOperate.h fileOperate.cpp -o 1.out -Wall
read -p "ok,press any key to continue" t
#echo $t
./1.out
echo "exit"

