/*
	time:2014-10-06 21:43
	author:halfopen
	version:1
*/
#ifndef FILEOPERATE_H_
#define FILEOPERATE_H_

#include <stdio.h>
#include <stdlib.h>
#include "LinkList.h"

void readData( LinkList *&L);
void writeData( LinkList *L);
void clearData();
#endif
