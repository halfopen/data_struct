#	time:2014-10-05 00.03
#	author:halfopen
#	version: 1
g++ 2_2.cpp SqList.cpp SqList.h readInput.cpp readInput.h -o 2_2.out 

read -p "ok,press anykey to continue" t
#echo $t
./2_2.out
