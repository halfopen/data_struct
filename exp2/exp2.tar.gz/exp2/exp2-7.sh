#
#	time:2014,10.06 14:22
#	author:halfopen	
#	version:1
g++ -Wall exp2-7.cpp -o exp2-7.out 
read -p "ok,press any key to continue" t
#echo t
./exp2-7.out
echo "exit"
