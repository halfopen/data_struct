#	time:2014-10-05 13.51
#	author:halfopen
#	version: 1
g++ 2_6.cpp LinkList.h LinkList.cpp  readInput.cpp readInput.h  -o 2_6.out
read -p "ok,press anykey to continue" t
#echo $t
./2_6.out
