/*
	time:2014-10-05 14:45
	author:halfopen
	version: 1

*/

#include <stdio.h>
#include <stdlib.h>

int readInput(int *&a);
