#	time:2014-10-05 08.49
#	author:halfopen
#	version: 1

g++ 2_5.cpp DLinkList.cpp DLinkList.h readInput.cpp readInput.h -o  2_5.out
echo "ok,press anykey to continue"
read t
#echo $t
./2_5.out


