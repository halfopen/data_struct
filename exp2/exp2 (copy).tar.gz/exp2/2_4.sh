#	time:2014-10-05 00.03
#	author:halfopen
#	version: 1
g++ 2_4.cpp LinkList.h LinkList.cpp  readInput.cpp readInput.h -o 2_4.out
echo "ok,press anykey to continue"
read t
#echo $t
./2_4.out
